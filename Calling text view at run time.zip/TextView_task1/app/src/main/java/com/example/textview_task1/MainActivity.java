package com.example.textview_task1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textDynamic;
    Button bold,caps,italic;
    String text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textDynamic=findViewById(R.id.textView);
        bold=findViewById(R.id.Bold);
        italic=findViewById(R.id.italic);
        caps=findViewById(R.id.capital);
        text="Welcome to MAD Class";
        textDynamic.setText(text);
        bold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Typeface b=Typeface.defaultFromStyle(Typeface.BOLD);
                textDynamic.setTypeface(b);
            }
        });

        italic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Typeface b=Typeface.defaultFromStyle(Typeface.ITALIC);
                textDynamic.setTypeface(b);
            }
        });
        caps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textDynamic.setAllCaps(true);
            }
        });




    }
}